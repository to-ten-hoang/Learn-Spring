package com.devteria.identify_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class IdentifyServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
